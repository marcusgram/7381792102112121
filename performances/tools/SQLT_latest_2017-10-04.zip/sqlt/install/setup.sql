REM $Header: setup.sql 11.4.5.0 2012/11/21 carlos.sierra $
@@sqcreate.sql